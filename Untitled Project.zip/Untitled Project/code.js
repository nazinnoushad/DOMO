onEvent("button1", "click", function() {
  // Capture values from input fields
  var name = getText("text_input1");
  var phone = getText("text_input2");
  var email = getText("text_input3");
  
  
  // Create the record with the captured data
  createRecord("record", {
    name: name,
    phone: phone,
    email: email
    
  }, function(record) {
    // Optional: Handle the callback after the record is created
    console.log("Record created:", record);
  });
});
